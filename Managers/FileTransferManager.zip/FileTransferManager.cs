using System;
using System.IO;
using System.Runtime.Versioning;
using System.Threading.Tasks;
using LuckyStars.Utils;

namespace LuckyStars.Managers
{
    /// <summary>
    /// 文件传输管理器 - 使用智能文件传输服务，防止线程泄漏和资源占用
    /// </summary>
    [SupportedOSPlatform("windows")]
    public class FileTransferManager
    {
        private readonly MainWindow _mainWindow;
        private readonly SmartFileTransferService _transferService;

        public FileTransferManager(MainWindow mainWindow)
        {
            _mainWindow = mainWindow;

            // 创建目标文件夹
            string targetFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
                "LuckyStarsWallpaper"
            );

            // 创建智能文件传输服务
            _transferService = new SmartFileTransferService(targetFolder);
        }

        /// <summary>
        /// 处理文件夹拖放
        /// </summary>
        public async Task ProcessFolderDrop(string folderPath)
        {
            if (!Directory.Exists(folderPath))
                return;

            try
            {
                // 使用文件传输服务处理文件夹
                var (_, _, firstAudioFile) = await _transferService.TransferFolderAsync(folderPath);

                // 如果有音频文件，播放它
                if (firstAudioFile != null && File.Exists(firstAudioFile))
                    _mainWindow?.HandleMusicFileDrop(firstAudioFile);
            }
            catch
            {
                // 忽略错误
            }
        }

        /// <summary>
        /// 处理单个文件拖放
        /// </summary>
        public (bool success, string? audioPath) ProcessSingleFileDrop(string filePath, bool playAudio = true)
        {
            if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
                return (false, null);

            try
            {
                // 使用文件传输服务处理单个文件
                var (success, audioPath) = _transferService.TransferSingleFile(filePath, playAudio);

                // 如果是音频文件，根据参数决定是否播放
                if (audioPath != null && playAudio)
                    _mainWindow?.HandleMusicFileDrop(audioPath);

                return (success, audioPath);
            }
            catch
            {
                return (false, null);
            }
        }
    }
}

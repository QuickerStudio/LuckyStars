using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Versioning;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace LuckyStars.Utils
{
    /// <summary>
    /// 智能文件传输服务 - 专注于线程生命周期管理和资源释放
    /// </summary>
    [SupportedOSPlatform("windows")]
    public class SmartFileTransferService
    {
        private readonly string _targetFolder;
        private readonly ConcurrentDictionary<int, Process> _activeProcesses = new();
        private readonly object _lockObject = new();
        private int _nextProcessId = 0;

        /// <summary>
        /// 初始化智能文件传输服务
        /// </summary>
        /// <param name="targetFolder">目标文件夹</param>
        public SmartFileTransferService(string targetFolder)
        {
            _targetFolder = targetFolder;

            // 确保目标文件夹存在
            Directory.CreateDirectory(_targetFolder);
        }

        /// <summary>
        /// 处理文件夹传输
        /// </summary>
        /// <param name="folderPath">文件夹路径</param>
        /// <returns>处理结果</returns>
        public async Task<(int total, int success, string? firstAudioFile)> TransferFolderAsync(string folderPath)
        {
            if (!Directory.Exists(folderPath))
                return (0, 0, null);

            try
            {
                // 取消之前的传输任务
                CancelTransfer();

                // 获取文件夹属性
                var folderInfo = GetFolderInfo(folderPath);

                // 使用单个进程处理，但确保完成后释放资源
                using var cts = new CancellationTokenSource();
                var (successCount, firstAudioFile) = await Task.Run(() =>
                {
                    return RunRobocopy(folderPath, _targetFolder, cts.Token);
                });

                return (folderInfo.fileCount, successCount, firstAudioFile);
            }
            catch
            {
                return (0, 0, null);
            }
        }

        /// <summary>
        /// 处理单个文件传输
        /// </summary>
        /// <param name="filePath">文件路径</param>
        /// <returns>处理结果</returns>
        public (bool success, string? audioPath) TransferSingleFile(string filePath, bool playAudio = true)
        {
            if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
                return (false, null);

            try
            {
                // 检查文件是否支持
                if (!SupportedFormats.IsSupportedFile(filePath))
                    return (false, null);

                string fileName = Path.GetFileName(filePath);
                string? sourceDir = Path.GetDirectoryName(filePath);

                // 确保源目录不为空
                if (string.IsNullOrEmpty(sourceDir))
                {
                    return (false, null);
                }

                // 使用单个进程处理，但确保完成后释放资源
                using var cts = new CancellationTokenSource();
                var (successCount, firstAudioFile) = RunRobocopy(sourceDir, _targetFolder, cts.Token, fileName);

                bool success = successCount > 0;
                bool isAudio = SupportedFormats.IsAudioFile(filePath);

                return (success, isAudio && playAudio && success ? firstAudioFile : null);
            }
            catch
            {
                return (false, null);
            }
        }

        /// <summary>
        /// 取消当前传输任务
        /// </summary>
        public void CancelTransfer()
        {
            try
            {
                // 终止所有活动进程
                foreach (var process in _activeProcesses.Values)
                {
                    try
                    {
                        if (!process.HasExited)
                        {
                            process.Kill();
                        }
                    }
                    catch
                    {
                        // 忽略终止进程时的错误
                    }
                    finally
                    {
                        process.Dispose();
                    }
                }

                // 清空进程字典
                _activeProcesses.Clear();
            }
            catch
            {
                // 忽略取消传输时的错误
            }
        }

        /// <summary>
        /// 获取文件夹信息（文件数量和文件夹数量）
        /// </summary>
        private (int fileCount, int folderCount) GetFolderInfo(string folderPath)
        {
            try
            {
                // 获取支持的文件格式
                var supportedExtensions = SupportedFormats.GetAllSupportedExtensions();

                // 计算文件数量（只计算支持的文件格式）
                int fileCount = Directory.GetFiles(folderPath, "*.*", SearchOption.TopDirectoryOnly)
                    .Count(f => supportedExtensions.Contains(Path.GetExtension(f).ToLowerInvariant()));

                // 计算子文件夹数量
                int folderCount = Directory.GetDirectories(folderPath).Length;

                return (fileCount, folderCount);
            }
            catch
            {
                return (0, 0);
            }
        }

        /// <summary>
        /// 运行 Robocopy 进程
        /// </summary>
        private (int successCount, string? firstAudioFile) RunRobocopy(
            string source,
            string destination,
            CancellationToken cancellationToken,
            string filePattern = "*.*")
        {
            // 获取支持的文件格式
            var supportedExtensions = SupportedFormats.GetAllSupportedExtensions();

            // 构建文件过滤参数
            string fileFilters = filePattern;

            // 如果是通配符模式，则使用支持的扩展名构建过滤器
            if (filePattern == "*.*")
            {
                fileFilters = string.Join(" ", supportedExtensions.Select(ext => $"*{ext}"));
            }

            // 创建进程启动信息
            var startInfo = new ProcessStartInfo
            {
                FileName = "robocopy",
                // 关键参数：/MT:8 多线程复制，/Z 断点续传，/S 包含子目录但不包含空目录
                // /NP 不显示进度，/NFL 不显示文件列表，/NDL 不显示目录列表
                Arguments = $"\"{source}\" \"{destination}\" {fileFilters} /S /MT:8 /Z /R:1 /W:1 /NP /NFL /NDL /NC /NS /COPY:DAT",
                UseShellExecute = false,
                CreateNoWindow = true, // 不显示控制台窗口
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };

            string? firstAudioFile = null;
            int successCount = 0;
            int processId = Interlocked.Increment(ref _nextProcessId);

            // 启动进程
            using var process = new Process { StartInfo = startInfo };

            try
            {
                _activeProcesses.TryAdd(processId, process);
                process.Start();

                // 设置取消令牌的回调，以便在取消时终止进程
                using var registration = cancellationToken.Register(() =>
                {
                    try
                    {
                        if (!process.HasExited)
                        {
                            process.Kill();
                        }
                    }
                    catch
                    {
                        // 忽略终止进程时的错误
                    }
                });

                // 读取输出和错误
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();

                // 等待进程完成，但设置超时以防止无限等待
                bool completed = process.WaitForExit(60000); // 60秒超时

                if (!completed)
                {
                    // 如果超时，强制终止进程
                    try
                    {
                        if (!process.HasExited)
                        {
                            process.Kill();
                        }
                    }
                    catch
                    {
                        // 忽略终止进程时的错误
                    }
                }
                else
                {
                    // 检查退出代码
                    int exitCode = process.ExitCode;

                    // Robocopy 退出代码:
                    // 0 - 没有文件被复制，没有失败
                    // 1 - 文件被成功复制
                    // 2 - 有额外的文件或目录，没有文件被复制
                    // 4 - 有不匹配的文件或目录，没有文件被复制
                    // 8 - 有文件复制失败
                    // 16 - 有严重错误

                    // 如果有严重错误，记录到日志
                    if (exitCode >= 16)
                    {
                        string logPath = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                            "LuckyStars",
                            "Logs"
                        );

                        Directory.CreateDirectory(logPath);

                        string logFile = Path.Combine(logPath, $"RobocopyError_{DateTime.Now:yyyyMMdd_HHmmss}.log");
                        File.WriteAllText(logFile, $"命令: robocopy {startInfo.Arguments}\n\n输出:\n{output}\n\n错误:\n{error}");
                    }

                    // 解析输出，获取成功传输的文件数
                    var match = Regex.Match(output, @"Files\s+:\s+(\d+)");
                    if (match.Success && int.TryParse(match.Groups[1].Value, out int count))
                    {
                        successCount = count;
                    }

                    // 查找第一个音频文件
                    if (successCount > 0)
                    {
                        var audioExtensions = new[] { ".mp3", ".wav", ".ogg", ".flac", ".aac", ".wma", ".m4a" };

                        foreach (var ext in audioExtensions)
                        {
                            string[] files = Directory.GetFiles(destination, $"*{ext}", SearchOption.AllDirectories);
                            if (files.Length > 0)
                            {
                                firstAudioFile = files[0];
                                break;
                            }
                        }
                    }
                }
            }
            catch
            {
                // 忽略执行 Robocopy 时的错误
            }
            finally
            {
                // 从活动进程列表中移除
                _activeProcesses.TryRemove(processId, out _);
            }

            return (successCount, firstAudioFile);
        }
    }
}

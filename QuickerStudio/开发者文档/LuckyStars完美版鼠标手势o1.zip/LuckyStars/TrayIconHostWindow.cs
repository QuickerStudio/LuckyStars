using LuckyStars;
using System.Windows.Forms;
using System;

namespace LuckyStars
{
    public class TrayIconHostWindow
    {
        private readonly NotifyIcon _notifyIcon;
        private readonly MainWindow _mainWindow;
        private bool _isWebViewActive = true;
        private bool _needReloadContent = false;

        public TrayIconHostWindow(MainWindow mainWindow)
        {
            _mainWindow = mainWindow ?? throw new ArgumentNullException(nameof(mainWindow));

            _notifyIcon = new NotifyIcon
            {
                Icon = new System.Drawing.Icon("Resource/UI/app.ico"),
                Visible = true
            };

            // 同时按下鼠标左右键：关闭程序
            _notifyIcon.MouseDown += (sender, e) =>
            {
                // 同时检测左右键是否都按下
                if ((Control.MouseButtons & MouseButtons.Left) != 0 &&
                    (Control.MouseButtons & MouseButtons.Right) != 0)
                {
                    System.Windows.Application.Current.Shutdown();
                }
            };

            // 左键双击：隐藏/显示壁纸
            // 右键双击：暂停/播放所有媒体 (音视频) - WebView2
            _notifyIcon.MouseDoubleClick += async (sender, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    ToggleWebView();
                }
                else if (e.Button == MouseButtons.Right)
                {
                    await ToggleAudio();
                }
            };
        }

        private async void ToggleWebView()
        {
            if (_isWebViewActive)
            {
                // 隐藏
                await _mainWindow.GetWebView().CoreWebView2.ExecuteScriptAsync(@"
                    document.body.style.display='none';
                    document.querySelectorAll('video, audio').forEach(media => media.pause());
                ");

                _mainWindow.GetWebView().CoreWebView2.Navigate("about:blank");
                _needReloadContent = true;
                _isWebViewActive = false;
            }
            else
            {
                // 恢复
                _mainWindow.SetWebViewVisibility(true);

                if (_needReloadContent)
                {
                    _mainWindow.LoadTestHtml();
                    _needReloadContent = false;
                }
                else
                {
                    await _mainWindow.GetWebView().CoreWebView2.ExecuteScriptAsync("document.body.style.display='block'");
                }

                _mainWindow.ApplyFullScreenToWebView();
                _isWebViewActive = true;
            }
        }

        private async System.Threading.Tasks.Task ToggleAudio()
        {
            // 暂停或播放所有音视频
            await _mainWindow.GetWebView().CoreWebView2.ExecuteScriptAsync(@"
                (() => {
                    const mediaElems = document.querySelectorAll('video, audio');
                    for (const m of mediaElems) {
                        if (m.paused) {
                            m.play();
                        } else {
                            m.pause();
                        }
                    }
                })();
            ");
        }

        public void Show()
        {
            _notifyIcon.Visible = true;
        }

        public void Hide()
        {
            _notifyIcon.Visible = false;
        }

        public void Dispose()
        {
            _notifyIcon.Dispose();
        }
    }
}
﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using Microsoft.Web.WebView2.Core;

namespace LuckyStars
{
    public partial class MainWindow : Window
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern uint GetDpiForWindow(IntPtr hwnd);

        private bool _isWebViewInitialized = false;

        public MainWindow()
        {
            InitializeComponent();

            // 设置窗口状态确保全屏
            this.WindowState = WindowState.Maximized;
            this.WindowStyle = WindowStyle.None;

            // 注册事件
            this.ContentRendered += Window_ContentRendered;
            this.SizeChanged += Window_SizeChanged;

            // 使用Loaded事件初始化WebView2
            this.Loaded += async (s, e) => {
                try
                {
                    // 确保WebView2初始化
                    await webView.EnsureCoreWebView2Async();

                    // 配置WebView2
                    webView.CoreWebView2.Settings.IsScriptEnabled = true;
                    webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
                    webView.DefaultBackgroundColor = System.Drawing.Color.Transparent;
                    // 添加键盘事件处理程序
                    webView.PreviewKeyDown += WebView_PreviewKeyDown;
                    _isWebViewInitialized = true;

                    // 设置WebView2大小并加载HTML
                    ApplyFullScreenToWebView();
                    LoadTestHtml();

                    // 关键：延迟后执行一次刷新以确保WebView2正确显示
                    // 方法1：使用 await 等待异步操作完成（推荐）
                    await Dispatcher.InvokeAsync(() => {
                        ApplyFullScreenToWebView();
                        webView.CoreWebView2?.Reload();
                    }, DispatcherPriority.ApplicationIdle);


                }
                catch (Exception ex)
                {
                    MessageBox.Show($"WebView2初始化失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }

            };
        }

        private void Window_ContentRendered(object? sender, EventArgs e)
        {
            try
            {
                // 使用高优先级确保在UI线程上执行
                Dispatcher.InvokeAsync(() => {
                    var hwnd = new WindowInteropHelper(this).Handle;
                    if (hwnd == IntPtr.Zero)
                    {
                        MessageBox.Show("无法获取窗口句柄", "警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    var dpi = GetDpiForWindow(hwnd);
                    if (dpi == 0)
                    {
                        dpi = 96; // 使用默认DPI值
                        MessageBox.Show("无法获取DPI，使用默认值", "警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }

                    ScaleWindowAndWebView(dpi);

                    // 额外调用以确保WebView2全屏
                    ApplyFullScreenToWebView();
                }, DispatcherPriority.Render);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"ContentRendered事件处理失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Window_SizeChanged(object? sender, SizeChangedEventArgs e)
        {
            try
            {
                Dispatcher.InvokeAsync(() => {
                    var hwnd = new WindowInteropHelper(this).Handle;
                    if (hwnd == IntPtr.Zero) return;

                    var dpi = GetDpiForWindow(hwnd);
                    if (dpi == 0) dpi = 96;

                    ScaleWebView(dpi);

                    // 额外调用以确保WebView2全屏
                    ApplyFullScreenToWebView();
                }, DispatcherPriority.Render);
            }
            catch (Exception ex)
            {
                // 记录日志但不显示消息框以避免频繁弹出
                Console.WriteLine($"SizeChanged事件处理失败: {ex.Message}");
            }
        }

        private void ScaleWindowAndWebView(uint dpi)
        {
            try
            {
                // 获取屏幕分辨率
                var screenWidth = SystemParameters.PrimaryScreenWidth;
                var screenHeight = SystemParameters.PrimaryScreenHeight;

                // 根据DPI缩放窗口
                this.Width = screenWidth * 96 / dpi;
                this.Height = screenHeight * 96 / dpi;

                // 设置WebView2的大小
                ScaleWebView(dpi);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"缩放窗口失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ScaleWebView(uint dpi)
        {
            if (webView == null) return;

            try
            {
                // 确保WebView2占据整个窗口
                webView.Width = this.ActualWidth;
                webView.Height = this.ActualHeight;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"缩放WebView失败: {ex.Message}");
            }
        }

        // 确保WebView2全屏显示的专用方法
        private void ApplyFullScreenToWebView()
        {
            if (webView == null) return;

            try
            {
                // 设置WebView2占据整个客户区
                webView.Width = double.NaN; // 自动填充
                webView.Height = double.NaN; // 自动填充

                // 确保WebView2正确对齐和拉伸
                webView.HorizontalAlignment = HorizontalAlignment.Stretch;
                webView.VerticalAlignment = VerticalAlignment.Stretch;

                // 使用控件的ActualWidth和ActualHeight确保精确匹配
                if (this.ActualWidth > 0 && this.ActualHeight > 0)
                {
                    webView.Width = this.ActualWidth;
                    webView.Height = this.ActualHeight;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"设置WebView全屏失败: {ex.Message}");
            }
        }
        private void WebView_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // 拦截 F5 键
            if (e.Key == Key.F5)
            {
                // 标记事件为已处理，这样 WebView2 就不会接收到这个按键了
                e.Handled = true;
            }
        }
        private void LoadTestHtml()
        {
            if (!_isWebViewInitialized || webView.CoreWebView2 == null)
            {
                MessageBox.Show("WebView2尚未初始化，无法加载HTML", "警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                string html = @"
                       <!DOCTYPE html>
<html lang=""en"">
<head>
    <meta charset=""UTF-8"">
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"">
    <title>LuckyStars</title>
    <style>
        /* 画布样式设置 */
        body {
            margin: 0;
            padding: 0;
            width: 100vw;
            height: 100vh;
            overflow: hidden;
        }
        canvas {
            position: fixed;  /* 固定定位 */
            top: 0;          /* 顶部对齐 */
            left: 0;         /* 左侧对齐 */
            width: 100%;     /* 宽度100% */
            height: 100%;    /* 高度100% */
            z-index: -1;     /* 置于底层 */
        }
    </style>
</head>
<body>
    <canvas id=""particleCanvas""></canvas>

    <script>
        // 参数变量集中管理
        const config = {
            particleSize: { min: 1, max: 4 }, // 粒子尺寸范围
            particleSpeed: { min: -1, max: 1 }, // 粒子速度范围
            mouseMaxDist: 200, // 鼠标影响最大距离
            maxLineDistColor: 10000, // 彩色粒子最大连线距离
            maxLineDistDot: 6000, // 点状粒子最大连线距离
            collisionDuration: 10, // 碰撞状态持续时间（帧数）
            glowRadiusFactor: 4.8, // 动态光晕半径因子
            glowRadiusOffset: 1.2, // 动态光晕半径偏移
            glowHueSpeed: 0.3, // 光晕色相变化速度
            mouseLineWidthFactor: 2, // 鼠标连线宽度因子
            mouseLineOpacityFactor: 0.5, // 鼠标连线透明度因子
            mouseLineLengthFactor: 8, // 鼠标连线长度因子
            randomColorChangeSpeed: 0.05 // 光晕颜色随机变化速度
        };

        // 初始化画布
        const canvas = document.getElementById('particleCanvas');
        const ctx = canvas.getContext('2d');
        
        // 确保画布占据整个窗口
        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        
        // 初始调整画布大小
        resizeCanvas();
        
        // 监听窗口大小变化
        window.addEventListener('resize', resizeCanvas);

        // 鼠标交互参数
        const mouse = { 
            x: null,         // 鼠标X坐标
            y: null,         // 鼠标Y坐标
            maxDist: config.mouseMaxDist     // 鼠标影响最大距离
        };

        // ================= 彩色粒子系统 =================
        class ColorParticle {
            constructor(x, y) {
                // 粒子参数
                this.x = x;                 // X坐标
                this.y = y;                 // Y坐标
                this.size = Math.random() * (config.particleSize.max - config.particleSize.min) + config.particleSize.min; // 粒子尺寸
                this.speedX = Math.random() * (config.particleSpeed.max - config.particleSpeed.min) + config.particleSpeed.min; // X轴速度
                this.speedY = Math.random() * (config.particleSpeed.max - config.particleSpeed.min) + config.particleSpeed.min; // Y轴速度
                this.color = `hsl(${Math.random() * 360}, 70%, 50%)`; // 随机HSL颜色
                this.collisionColor = null; // 碰撞时颜色状态
                this.collisionTimer = 0;    // 碰撞状态持续时间（帧数）
                this.isConnectedToMouse = false; // 是否与鼠标连线连接
                this.originalColor = this.color; // 初始颜色
            }

            draw() {
                ctx.fillStyle = this.color;
                ctx.beginPath();
                this.drawStar(ctx, this.x, this.y, this.size, this.size * 2, 5);
                ctx.fill();
            }

            drawStar(ctx, x, y, radius1, radius2, points) {
                let angle = Math.PI / points;
                ctx.beginPath();
                for (let i = 0; i < 2 * points; i++) {
                    let radius = i % 2 === 0 ? radius2 : radius1;
                    ctx.lineTo(x + Math.cos(i * angle) * radius, y + Math.sin(i * angle) * radius);
                }
                ctx.closePath();
            }

            update() {
                // 鼠标引力影响
                if (mouse.x && mouse.y) {
                    const dx = mouse.x - this.x;
                    const dy = mouse.y - this.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    if (distance < mouse.maxDist) {
                        this.speedX += dx * 0.0005; // X轴加速度
                        this.speedY += dy * 0.0005; // Y轴加速度
                    }
                }

                // 位置更新
                this.x += this.speedX;
                this.y += this.speedY;
                
                // 边界反弹处理
                if (this.x > canvas.width - this.size) {
                    this.speedX *= -0.8; // X轴速度衰减
                    this.x = canvas.width - this.size;
                } else if (this.x < this.size) {
                    this.speedX *= -0.8;
                    this.x = this.size;
                }

                if (this.y > canvas.height - this.size) {
                    this.speedY *= -0.8; // Y轴速度衰减
                    this.y = canvas.height - this.size;
                } else if (this.y < this.size) {
                    this.speedY *= -0.8;
                    this.y = this.size;
                }

                // 碰撞状态更新
                if (this.collisionTimer > 0) {
                    this.collisionTimer--;
                    if (this.collisionTimer === 0) {
                        this.collisionColor = null; // 重置碰撞颜色
                    }
                }

                // 光晕颜色更新
                if (this.isConnectedToMouse) {
                    this.color = `hsl(${Math.random() * 360}, 70%, 50%)`; // 随机HSL颜色
                } else {
                    this.color = this.originalColor; // 保持断开后的颜色
                }
            }
        }

        // ================= 点状粒子系统 =================
        class DotParticle {
            constructor() {
                this.x = Math.random() * canvas.width;  // 初始X坐标
                this.y = Math.random() * canvas.height; // 初始Y坐标
                this.xa = Math.random() * (config.particleSpeed.max - config.particleSpeed.min) + config.particleSpeed.min; // X轴加速度
                this.ya = Math.random() * (config.particleSpeed.max - config.particleSpeed.min) + config.particleSpeed.min; // Y轴加速度
                this.color = `hsl(${Math.random() * 360}, 80%, 60%)`; // 颜色设置
                this.maxDist = config.maxLineDistDot;        // 鼠标影响距离阈值（平方值）
                this.collisionColor = null; // 碰撞颜色状态
                                this.collisionTimer = 0;    // 碰撞状态计时
                this.isConnectedToMouse = false; // 是否与鼠标连线连接
                this.originalColor = this.color; // 初始颜色
            }

            update() {
                // 鼠标引力影响
                if (mouse.x && mouse.y) {
                    const dx = mouse.x - this.x;
                    const dy = mouse.y - this.y;
                    const distance = dx * dx + dy * dy;
                    if (distance < this.maxDist) {
                        this.xa += dx * 0.0002; // X轴加速度
                        this.ya += dy * 0.0002; // Y轴加速度
                    }
                }

                // 位置更新
                this.x += this.xa;
                this.y += this.ya;
                
                // 边界反弹处理
                this.xa *= (this.x > canvas.width || this.x < 0) ? -0.8 : 1;
                this.ya *= (this.y > canvas.height || this.y < 0) ? -0.8 : 1;

                // 碰撞状态更新
                if (this.collisionTimer > 0) {
                    this.collisionTimer--;
                    if (this.collisionTimer === 0) {
                        this.collisionColor = null;
                    }
                }

                // 光晕颜色更新
                if (this.isConnectedToMouse) {
                    this.color = `hsl(${Math.random() * 360}, 80%, 60%)`; // 随机HSL颜色
                } else {
                    this.color = this.originalColor; // 保持断开后的颜色
                }
            }
        }

        // ================= 系统初始化 =================
        const colorParticles = Array.from({ length: 150 }, () => // 150个彩色粒子
            new ColorParticle(Math.random() * canvas.width, Math.random() * canvas.height)
        );

        const dotParticles = Array.from({ length: 99 }, () => // 99个点状粒子
            new DotParticle()
        );

        // ================= 连线绘制系统 =================
        function drawLines(particles, maxDistance) {
            // 碰撞检测系统
            const collisionPairs = new Set();
            const checkDistance = Math.sqrt(maxDistance) * 0.8; // 预计算检测距离

            // 粒子间碰撞检测
            for (let i = 0; i < particles.length; i++) {
                for (let j = i + 1; j < particles.length; j++) {
                    const a = particles[i];
                    const b = particles[j];
                    const dx = a.x - b.x;
                    const dy = a.y - b.y;
                    const distanceSq = dx*dx + dy*dy;

                    if (distanceSq < (checkDistance * checkDistance)) {
                        const realDistance = Math.sqrt(distanceSq);
                        const minDist = (a.size || 1) + (b.size || 1); // 最小碰撞距离
                        
                        if (realDistance < minDist) {
                            collisionPairs.add([a, b]);
                            // 设置碰撞颜色（90%透明度）
                            a.collisionColor = `hsla(${Math.random() * 360}, 70%, 50%, 0.9)`;
                            b.collisionColor = a.collisionColor;
                            a.collisionTimer = config.collisionDuration; // 维持10帧
                            b.collisionTimer = config.collisionDuration;
                        }
                    }
                }
            }

            // 连线绘制逻辑
            particles.forEach(a => {
                particles.forEach(b => {
                    if (a === b) return;

                    const dx = a.x - b.x;
                    const dy = a.y - b.y;
                    const distance = dx*dx + dy*dy;

                    if (distance < maxDistance) {
                        ctx.beginPath();
                        // 连线颜色优先使用碰撞颜色
                        const lineColor = a.collisionColor || 
                            `hsla(${a.color.split('hsl(')[1].split(')')[0]}, 0.2)`;
                        
                        ctx.strokeStyle = lineColor;
                        ctx.lineWidth = 1 - (Math.sqrt(distance) / Math.sqrt(maxDistance));
                        
                        ctx.moveTo(a.x, a.y);
                        ctx.lineTo(b.x, b.y);
                        ctx.stroke();
                    }
                });

                // 鼠标连线处理
                if (mouse.x && mouse.y) {
                    const dx = a.x - mouse.x;
                    const dy = a.y - mouse.y;
                    const distance = dx*dx + dy*dy;
                    if (distance < maxDistance * config.mouseLineLengthFactor) { // 鼠标连线长度增加8倍
                        ctx.beginPath();
                        ctx.strokeStyle = `hsla(${a.color.split('hsl(')[1].split(')')[0]}, ${config.mouseLineOpacityFactor})`; // 鼠标连线透明度提高30%
                        ctx.lineWidth = config.mouseLineWidthFactor - (Math.sqrt(distance) / Math.sqrt(maxDistance)); // 鼠标连线宽度增加2倍
                        ctx.moveTo(a.x, a.y);
                        ctx.lineTo(mouse.x, mouse.y);
                        ctx.stroke();

                        // 更新粒子连接状态
                        a.isConnectedToMouse = true;
                    } else {
                        // 断开连接后保持颜色
                        a.isConnectedToMouse = false;
                    }
                } else {
                    // 断开连接后保持颜色
                    a.isConnectedToMouse = false;
                }
            });
        }

        // ================= 动画循环系统 =================
        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // 更新彩色粒子系统
            colorParticles.forEach(p => {
                p.update();
                p.draw();
            });
            drawLines(colorParticles, config.maxLineDistColor); // 最大连线距离10000（平方值）

            // 更新点状粒子系统
            dotParticles.forEach(p => {
                p.update();
                ctx.fillStyle = p.color;
                ctx.fillRect(p.x - 1, p.y - 1, 2, 2); // 绘制2x2像素点
            });
            drawLines(dotParticles, config.maxLineDistDot); // 最大连线距离6000（平方值）

            // ================= 光效系统 ================= 
            let hue = 0; // 全局色相控制
            function applyGlow() {
                ctx.save();
                ctx.globalCompositeOperation = 'lighter'; // 使用叠加混合模式
                
                colorParticles.forEach(p => {
                    // 动态光晕半径（减少40%）
                    const dynamicRadius = p.size * (config.glowRadiusFactor + Math.sin(Date.now()*0.0008 + p.x)*config.glowRadiusOffset);
                    
                    // 创建径向渐变
                    const gradient = ctx.createRadialGradient(
                        p.x, p.y, 0, 
                        p.x, p.y, dynamicRadius
                    );
                    gradient.addColorStop(0, `hsla(${(hue + p.x/10) % 360}, 80%, 60%, 0.3)`);
                    gradient.addColorStop(1, 'transparent');

                    // 绘制光晕
                    ctx.fillStyle = gradient;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, dynamicRadius, 0, Math.PI*2);
                    ctx.fill();
                });
                
                ctx.restore();
                hue = (hue + config.glowHueSpeed) % 360; // 色相变化速度
            }

            applyGlow(); // 应用光效
            requestAnimationFrame(animate);
        }

        // ================= 事件监听系统 =================
        window.addEventListener('mousemove', e => {
            mouse.x = e.clientX;
            mouse.y = e.clientY;
        });

        window.addEventListener('mouseout', () => {
            mouse.x = null;
            mouse.y = null;
        });

        window.addEventListener('resize', () => {
            // 窗口大小调整处理
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            // 重置粒子位置
            colorParticles.forEach(p => {
                p.x = Math.random() * canvas.width;
                p.y = Math.random() * canvas.height;
            });
            dotParticles.forEach(p => {
                p.x = Math.random() * canvas.width;
                p.y = Math.random() * canvas.height;
            });
        });

        animate();
    </script>
</body>
</html>
";

                // 加载HTML到WebView2
                webView.CoreWebView2.NavigateToString(html);



                // 重要：HTML加载后强制刷新一次WebView2大小
                Dispatcher.InvokeAsync(() => {
                    ApplyFullScreenToWebView();

                    // 3秒后再次刷新一次
                    DispatcherTimer timer = new DispatcherTimer();
                    timer.Interval = TimeSpan.FromSeconds(3);
                    timer.Tick += (s, e) => {
                        ApplyFullScreenToWebView();
                        webView.CoreWebView2?.Reload();
                        timer.Stop(); // 确保只执行一次
                    };
                    timer.Start();
                }, DispatcherPriority.ApplicationIdle);

            } catch (Exception ex) {
                MessageBox.Show($"加载HTML失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}